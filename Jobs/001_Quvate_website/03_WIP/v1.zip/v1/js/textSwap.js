// var home_knockout_text = $("#home").find('knockout-text');
var home_knockout_text = $("#home").children("h1.knockout-text");

console.log(home_knockout_text);